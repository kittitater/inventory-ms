
// import { Inter } from 'next/font/google'
import Welcome from '@/components/Welcome';
import Head from 'next/head'
// import Welcome from '@/components/Welcome'

export default function Home() {
  return (
  <div className='sm:ml-64'>
    <Welcome/>
    
  </div>
    
  );
}
